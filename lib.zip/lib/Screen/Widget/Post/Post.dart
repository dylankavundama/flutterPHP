import 'package:flutter/material.dart';

class PostWidget extends StatefulWidget {
  const PostWidget({
    Key? key,
    required this.screenW,
    required this.screenH,
    required this.date,
    required this.description,
    required this.image,
    required this.titre,
    required this.categories,
    required this.index,
  }) : super(key: key);

  final double screenW;
  final double screenH;
  final String image;
  final String titre;
  final String description;

  final String date;
  final String categories;
  final int index;

  @override
  State<PostWidget> createState() => _PostWidgetState();
}

class _PostWidgetState extends State<PostWidget> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Container(
          color: Colors.white,
          width: widget.screenW,
          height: widget.screenH * 0.2,
          child: Padding(
            padding: const EdgeInsets.only(left: 6, top: 0),
            child: Row(
              children: [
                Image.network(
                  'http://192.168.53.195/test/postimages/${widget.image}',
                  width: widget.screenW * 0.3,
                  height: widget.screenH,
                  fit: BoxFit.cover,
                ),
                Container(
                  width: widget.screenW * 0.6,
                  height: widget.screenH * 0.3,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            height: widget.screenH * 0.01,
                            // width: widget.screenW * 0.05,

                            child: Center(
                              child: Text(
                                '${widget.index}',
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '${widget.titre}',
                            maxLines: 1,
                            style: TextStyle(
                              color: Colors.blue.shade400,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 0.1,
                      ),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          '${widget.description}...',
                          textAlign: TextAlign.start,
                          style: const TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.normal,
                          ),
                          maxLines: 4,
                        ),
                      ),
                      const SizedBox(
                        height: 1,
                      ),
                      
                      Text(
                        ' ${widget.date}',
                        style: TextStyle(color: Colors.black),
                      ),
                      Divider(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
